
CREATE TABLE `Funciones` (
  `id_funcion` int(11) NOT NULL,
  `id_cine` int(11) NOT NULL,
  `id_sala` int(11) NOT NULL,
  `id_pelicula` int(11) NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `Funciones` (`id_funcion`, `id_cine`, `id_sala`, `id_pelicula`, `fecha_hora`) VALUES
(2, 1, 2, 2, '2019-11-10 06:36:00'),
(3, 1, 2, 4, '2019-11-13 06:05:00'),
(4, 1, 2, 1, '2019-11-14 07:01:00'),
(7, 4, 1, 1, '2019-11-12 11:34:00'),
(8, 3, 3, 5, '2019-11-15 06:32:00'),
(9, 1, 2, 4, '2019-11-11 14:15:00'),
(10, 1, 2, 2, '2019-11-13 09:16:00'),
(11, 1, 2, 100, '2019-11-15 10:17:00'),
(12, 1, 2, 11, '2019-11-11 05:02:00'),
(13, 2, 4, 38, '2019-11-12 08:38:00');
