
CREATE TABLE `Usuarios` (
  `id_usuario` int(11) NOT NULL,
  `dni` int(11) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `rol` tinyint(1) NOT NULL,
  `ip` varchar(32) DEFAULT NULL,
  `registerDate` int(11) DEFAULT NULL,
  `lastConnection` int(11) DEFAULT NULL,
  `loggedIn` tinyint(1) DEFAULT NULL,
  `image` varchar(256) DEFAULT NULL,
  `facebookId` bigint(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `Usuarios` (`id_usuario`, `dni`, `password`, `email`, `apellido`, `nombre`, `rol`, `ip`, `registerDate`, `lastConnection`, `loggedIn`, `image`, `facebookId`) VALUES
(1, 37777777, 'admin', 'moviepass.arg@gmail.com', 'Pass', 'Movie', 3, '::1', 1573100064, 1573509250, 1, 'Views/img/avatar.png', NULL),
(2, 38831867, '123456', 'rodrii_cs@hotmail.com', 'Fanjul', 'Rodrigo', 3, '::1', 1571886736, 1573520198, 0, 'https://graph.facebook.com/1874330122626592/picture?type=square&height=200', 1874330122626592),
(3, 38831866, '1234', 'rodrii.fan@gmail.com', 'Fanjul', 'Rodrigo', 1, '::1', 1571886976, 1573520415, 0, 'Views/img/avatar.png', NULL),
(4, 41570767, '1234', 'micael15papa@gmail.com', 'Papa', 'Micael', 1, '::1', 1571959317, 1571959318, 0, 'Views/img/avatar.png', NULL),
(5, 123457262, '123456', 'piberenz@gmail.com', 'Berenz', 'Pamela', 1, '::1', 1573418831, 1573509239, 0, 'Views/img/avatar.png', NULL);
