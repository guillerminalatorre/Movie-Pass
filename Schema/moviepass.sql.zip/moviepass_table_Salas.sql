
CREATE TABLE `Salas` (
  `id_sala` int(11) NOT NULL,
  `id_cine` int(11) NOT NULL,
  `nombre` varchar(128) NOT NULL,
  `precio` int(11) NOT NULL,
  `capacidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `Salas` (`id_sala`, `id_cine`, `nombre`, `precio`, `capacidad`) VALUES
(1, 4, 'Tiffany', 350, 100),
(2, 1, 'Tiffany', 350, 100),
(3, 3, 'Atmos', 250, 150),
(4, 2, 'Aldrito', 190, 200);
