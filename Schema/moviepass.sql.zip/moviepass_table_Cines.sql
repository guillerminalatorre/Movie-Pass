
CREATE TABLE `Cines` (
  `id_cine` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `direccion` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `Cines` (`id_cine`, `nombre`, `direccion`) VALUES
(1, 'Ambassador', 'Cordoba 2551'),
(2, 'Aldrey', 'Sarmiento 2685'),
(3, 'Los Gallegos', 'Rivadavia 3050'),
(4, 'Cine del Paseo', 'Diagonal Pueyrredón 3058');
